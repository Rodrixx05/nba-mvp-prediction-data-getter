Function to push new data to the NBA MVP Prediction App in Google Cloud Platform.
